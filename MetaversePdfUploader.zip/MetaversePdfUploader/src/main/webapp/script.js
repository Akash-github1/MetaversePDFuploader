function email_validation() {
	var email = document.getElementById("email").value;
	var passwd = document.getElementById("passwd").value;
	if(email.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)){
		return true;
	}
}

function validation(){
	
}
