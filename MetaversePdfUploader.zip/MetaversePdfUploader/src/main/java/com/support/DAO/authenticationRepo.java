package com.support.DAO;

import org.springframework.data.repository.CrudRepository;

import com.support.bean.authenticationTable;

public interface authenticationRepo extends CrudRepository<authenticationTable,String> {

}
