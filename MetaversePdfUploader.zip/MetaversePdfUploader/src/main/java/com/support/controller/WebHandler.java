package com.support.controller;

import java.io.BufferedReader;
import java.io.File;  
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.python.util.PythonInterpreter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.support.DAO.authenticationRepo;
import com.support.bean.authenticationTable;


@Controller
public class WebHandler {
	@Autowired
	authenticationRepo authDao;

	public static String uploadDirectory = System.getProperty("user.dir") + "/uploads";

	@RequestMapping("/")
	public ModelAndView homepage() {
		ModelAndView mv = new ModelAndView();
		authenticationTable auth = new authenticationTable();
//usr-1
		auth.setEmail("test1@gmail.com");
		auth.setPasswd("test123");
		authDao.save(auth);

// usr-2
		auth.setEmail("test2@gmail.com");
		auth.setPasswd("test123");
		authDao.save(auth);

		mv.setViewName("Login.jsp");
		return mv;
	}

	@RequestMapping("/upload")
	public ModelAndView login(@RequestParam("passwd") String passwd, @RequestParam("email") String email) {
		ModelAndView mv = new ModelAndView();
		try {
			authenticationTable aut = authDao.findById(email).get();
			if (email.isBlank()) {
				mv.setViewName("Login.jsp");
				mv.addObject("message", "*Email Field is Empty.");
			} else if (passwd.isBlank()) {
				mv.setViewName("Login.jsp");
				mv.addObject("message", "*Password Field is Empty.");
			} else if (passwd.isBlank() && email.isBlank()) {
				mv.setViewName("Login.jsp");
				mv.addObject("message", "*Both Fields are Empty.");
			} else if (passwd.equals(aut.getPasswd()) && email.equals(aut.getEmail())) {
				mv.setViewName("uploadPdf.jsp");
				mv.addObject("message", "*Login successfully.");

			} else {
				mv.setViewName("Login.jsp");
				mv.addObject("message", "*Invalid Password.");
			}
		} catch (Exception e) {
			mv.setViewName("Login.jsp");
			mv.addObject("message", "*Invalid Email");
		}
		return mv;
	}

	@RequestMapping("/output")
	public ModelAndView output(@RequestParam("email") String email, @RequestParam("myfile") MultipartFile myfile)
			throws IOException, InterruptedException {
		ModelAndView mv = new ModelAndView();
		System.out.println(myfile);
		Path fileNameAndPath = Paths.get(uploadDirectory, myfile.getOriginalFilename());
		try {
			Files.write(fileNameAndPath, myfile.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		Thread.sleep(4000);
		File file = new File(System.getProperty("user.dir") + "/uploads/"+myfile.getOriginalFilename());
		FileInputStream fis = new FileInputStream(file);

		PDDocument pdfDocument = PDDocument.load(fis);
		System.out.println(pdfDocument.getPages().getCount());
		PDFTextStripper pdfTextStripper = new PDFTextStripper();
		String docText = pdfTextStripper.getText(pdfDocument);
		System.out.println(docText);
		pdfDocument.close();
		fis.close();
		
		
		
		
		
		PythonInterpreter pyInterp = new PythonInterpreter();
		      pyInterp.exec("print('Hello Python World!')");
//	    Pattern pattern = Pattern.compile("Name: [A-Za-z]{2,25} [A-Za-z]{2,25}", Pattern.CASE_INSENSITIVE);
//	    Matcher matcher = pattern.matcher(docText);
//	    boolean matchFound = matcher.find();
//	    if(matchFound) {
//	      System.out.println(matcher.group());
//	    } else {
//	      System.out.println("Match not found");
//	    }

		//		String fileData = Base64.encodeFromFile(file.getAbsolutePath());
//		OkHttpClient client = new OkHttpClient();
//		  MediaType mediaType = MediaType.parse("application/javascript");
//		  RequestBody body = RequestBody.create(mediaType, "{"+ "doc_base64:" + fileData+ ",req_id: '< req id string >', doc_type: pdf}");
//		  Request request = new Request.Builder()
//			.url("https://ping.arya.ai/api/v1/resume-parser")
//			.method("POST", body)
//			.addHeader("token", "cb77fccbf460699da62bedbe4bd4af4d")
//			.addHeader("content-type", "application/json")
//			.build();
//		  Response response = client.newCall(request).execute();
//		  System.out.println(response.toString());

//	       String[] command = {"curl", "-X", "POST",
//	    		   "https://api.superparser.com/parse" ,
//	    		   "-H", "accept: application/json",
//	    		   "-H", "X-API-Key: ePXZ4iDrNF7vZVx1uRnlr4apq2A4Oc981ykKMLOs",
//	    		   "-H", "Content-Type: multipart/form-data",
//	    		   "-F", "file_name=@Harsh-Shrivastava-Resume.pdf;type=application/pdf"};
//	        ProcessBuilder process = new ProcessBuilder(command); 
//	        Process p;
//	        try
//	        {
//	            p = process.start();
//	             BufferedReader reader =  new BufferedReader(new InputStreamReader(p.getInputStream()));
//	                StringBuilder builder = new StringBuilder();
//	                String line = null;
//	                while ( (line = reader.readLine()) != null) {
//	                        builder.append(line);
//	                        builder.append(System.getProperty("line.separator"));
//	                }
//	                String result = builder.toString();
//	                System.out.print(result);
//
//	        }
//	        catch (IOException e)
//	        {   System.out.print("error");
//	            e.printStackTrace();
//	        }
		
		mv.setViewName("uploadPdf.jsp");
		return mv;
	}

}