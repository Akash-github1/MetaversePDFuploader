package com.support;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.support.controller.WebHandler;

@SpringBootApplication
@ComponentScan({"com.support","WebHandler"})
public class MetaversePdfUploader {

	public static void main(String[] args) {
		new File(WebHandler.uploadDirectory).mkdir();
		SpringApplication.run(MetaversePdfUploader.class, args);
	}

}
