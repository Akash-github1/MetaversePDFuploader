package com.example.RchilliApi;

import java.io.*;   
import java.net.*;

public class program {

	//Set APIURL as rest api url for resume parsing provided by RChilli.
	static final String APIURL = "http://192.168.1.111/RChilliParser8/Rchilli/parseResumeBinary";
	
	//Set USERKEY as provided by RChilli.
	static final String USERKEY = "0001111";
	static final String VERSION = "8.0.0";

	public static void main(String[] args) {
		
		String filePath = System.getProperty("user.dir") + "/uploads/Resume.pdf";
		File resumeFile = new File(filePath);
		try {
			String fileData = Base64.encodeFromFile(resumeFile.getAbsolutePath());
			String subUserId = "Please change as per aggreement";
			String request = "{" 
								+ "\"filedata\":\"" + fileData + "\"," 
								+ "\"filename\":\"" + resumeFile.getName() + "\"," 
								+ "\"userkey\":\"" + USERKEY + "\"," 
								+ "\"version\":\"" + VERSION + "\","
								+ "\"subuserid\":\"" + subUserId + "\"" 
								+ "}";

			URL url = new URL(APIURL);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStream os = conn.getOutputStream();
			os.write(request.getBytes());
			os.flush();
			BufferedReader br = null;
			if (conn.getResponseCode() != 200) {

				br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			} else {
				br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			}
			String output;
			StringBuilder sbOutput = new StringBuilder();
			while ((output = br.readLine()) != null) {
				sbOutput.append(output);
			}
			conn.disconnect();
			br.close();
			output = sbOutput.toString();
			System.out.println(output);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
